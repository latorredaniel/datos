import React, { useState } from "react";
import SwaggerUI from "swagger-ui-react";
import "swagger-ui-react/swagger-ui.css";

export default function App() {
    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [downloadUrl, setDownloadUrl] = useState(null);
    const [yamlUrl, setYamlUrl] = useState(null);
    const [message, setMessage] = useState("");

    const API_BASE = "http://localhost:8000"; // ⚙️ cambia esto al dominio del backend en producción

    // 📤 1️⃣ Subir Excel y generar YAML
    const handleUpload = async () => {
        if (!file) {
            setMessage("Por favor selecciona un archivo Excel.");
            return;
        }

        setLoading(true);
        setMessage("Procesando archivo...");

        try {
            const formData = new FormData();
            formData.append("file", file);

            const res = await fetch(`${API_BASE}/generate`, {
                method: "POST",
                body: formData,
            });

            const data = await res.json();

            if (!res.ok) throw new Error(data.error || "Error al generar YAML");

            setDownloadUrl(data.download_url);
            setYamlUrl(data.download_url); // 👈 para mostrarlo en Swagger UI
            setMessage("✅ Archivo YAML generado correctamente. Puedes visualizarlo abajo o descargarlo.");
        } catch (err) {
            setMessage("❌ " + err.message);
        } finally {
            setLoading(false);
        }
    };

    // 📥 2️⃣ Descargar archivo y limpiar automáticamente
    const handleDownloadAndCleanup = async () => {
        if (!downloadUrl) return;

        try {
            // Descargar el archivo
            const res = await fetch(downloadUrl);
            if (!res.ok) throw new Error("Error al descargar el archivo.");

            const blob = await res.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = downloadUrl.split("/").pop();
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);

            // Mensaje intermedio
            setMessage("📦 Archivo descargado.");

            // Obtener nombre del archivo del URL
            const filename = downloadUrl.split("/").pop();

            // Llamar al nuevo endpoint DELETE /cleanup/{filename}
            await fetch(`${API_BASE}/cleanup/${filename}`, { method: "DELETE" });

            // Mostrar mensaje final y recargar
            setMessage("✅ Descarga completa.");
            setTimeout(() => {
                window.location.reload(); // 🔁 Recarga limpia la interfaz
            }, 2000);
        } catch (err) {
            setMessage("❌ Error durante la descarga: " + err.message);
        }
    };

    return (
        <div style={styles.container}>
            <h1>Automatizador de OpenAPI</h1>

            {/* Subir archivo */}
            <input
                type="file"
                accept=".xlsx"
                onChange={(e) => setFile(e.target.files[0])}
                style={styles.input}
            />

            <button onClick={handleUpload} disabled={!file || loading} style={styles.button}>
                {loading ? "Procesando..." : "Generar YAML"}
            </button>

            {/* Mostrar botón de descarga y visor */}
            {downloadUrl && (
                <div style={styles.result}>
                    <p>Archivo listo:</p>
                    <button onClick={handleDownloadAndCleanup} style={styles.downloadBtn}>
                        Descargar
                    </button>

                    {/* 👇 Swagger UI Viewer */}
                    <div style={{ marginTop: "30px", textAlign: "left" }}>
                        <h3>📘 Vista previa del OpenAPI</h3>
                        <SwaggerUI url={yamlUrl} />
                    </div>
                </div>
            )}

            {/* Mensajes */}
            {message && <p style={styles.message}>{message}</p>}
        </div>
    );
}

// 💅 Estilos simples
const styles = {
    container: {
        fontFamily: "Arial, sans-serif",
        textAlign: "center",
        marginTop: "50px",
    },
    input: {
        marginBottom: "10px",
    },
    button: {
        backgroundColor: "#007bff",
        color: "#fff",
        padding: "10px 20px",
        border: "none",
        borderRadius: "6px",
        cursor: "pointer",
        marginLeft: "5px",
    },
    downloadBtn: {
        backgroundColor: "#28a745",
        color: "#fff",
        padding: "8px 15px",
        border: "none",
        borderRadius: "6px",
        cursor: "pointer",
    },
    result: {
        marginTop: "20px",
    },
    message: {
        marginTop: "20px",
        fontWeight: "bold",
    },
};

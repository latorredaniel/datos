import React, { useState } from "react";
import SwaggerUI from "swagger-ui-react";
import "swagger-ui-react/swagger-ui.css";

export default function OpenApiWizard() {
    const [step, setStep] = useState(1);
    const [selectedFile, setSelectedFile] = useState(null);
    const [downloadUrl, setDownloadUrl] = useState(null);
    const [filename, setFilename] = useState(null);
    const [loading, setLoading] = useState(false);

    const API_BASE = process.env.REACT_APP_API_BASE || "http://localhost:8080"; // cambia esto al dominio del backend en producción

    const handleFileUpload = (e) => {
        setSelectedFile(e.target.files[0]);
    };

    const handleGenerate = async () => {
        if (!selectedFile) return;
        setLoading(true);
        const formData = new FormData();
        formData.append("file", selectedFile);

        try {
            const res = await fetch(`${API_BASE}/generate`, {
                method: "POST",
                body: formData,
            });
            const data = await res.json();

            if (res.ok && data.download_url) {
                setDownloadUrl(data.download_url);
                const file = data.download_url.split("/").pop();
                setFilename(file);
                setStep(2);
            } else {
                alert("Error al generar archivo");
            }
        } catch (err) {
            alert("Error al conectar con el backend");
        } finally {
            setLoading(false);
        }
    };

    const handleDownload = async () => {
        if (!filename) return;

        // Descargar archivo
        const res = await fetch(downloadUrl);
        const blob = await res.blob();
        const a = document.createElement("a");
        a.href = window.URL.createObjectURL(blob);
        a.download = filename;
        a.click();

        // Limpiar backend
        await fetch(`${API_BASE}/cleanup/${filename}`, {
            method: "DELETE",
        });

        // Reiniciar flujo
        setStep(1);
        setSelectedFile(null);
        setFilename(null);
        setDownloadUrl(null);
    };

    return (
        <div className="p-8 max-w-4xl mx-auto bg-gray-80 text-gray-800 min-h-screen">
            {/* Banner superior con logo */}
            <div className="flex items-center justify-between bg-[#fb9cb9] text-white px-6 py-4 rounded-lg shadow-md mb-8">
                <div className="flex items-center space-x-4">
                    <h1 className="text-2xl font-semibold">Generación de OpenAPI</h1>
                </div>
            </div>
            {/* Barra de pasos */}
            <div className="relative flex justify-between items-center mb-8 w-3/4 mx-auto ">
                {["Paso 1: Subir", "Paso 2: Visualizar", "Paso 3: Descargar"].map((label, i, arr) => (
                    <div key={i} className="flex flex-col items-center w-1/3 relative">
                        {/* 🔹 Línea entre círculos (con margen lateral) */}
                        {i < arr.length - 1 && (
                            <div
                                className="
                                absolute 
                                top-[50%]  
                                left-[60%] 
                                h-[1px] 
                                bg-[#a3a3a3] 
                                z-0 
                                transform 
                                -translate-y-[12px] 
                                w-[80%]
                            "
                            ></div>
                        )}

                        {/* Círculo */}
                        <div
                            className={`relative z-10 w-10 h-10 flex items-center justify-center rounded-full border-2  ${step === i + 1
                                ? "bg-[#e75f88] border-[#e75f88] text-white"
                                : "border-gray-400 text-gray-600 bg-white"
                                }`}
                        >
                            {i + 1}
                        </div>

                        {/* Etiqueta */}
                        <p className="mt-2 text-sm text-gray-700">{label}</p>
                    </div>
                ))}
            </div>

            {/* Paso 1 */}
            {step === 1 && (
                <div className="space-y-4">
                    <h2 className="text-xl font-semibold text-gray-700">Paso 1: Subir archivo</h2>
                    <input
                        type="file"
                        accept=".xlsx, .xls"
                        onChange={handleFileUpload}
                        className="block text-sm text-gray-600"
                    />
                    <button
                        className="bg-[#929292] px-4 py-2 rounded text-white disabled:opacity-50"
                        onClick={handleGenerate}
                        disabled={!selectedFile || loading}
                    >
                        {loading ? "Generando..." : "Generar OpenAPI"}
                    </button>
                </div>
            )}

            {/* Paso 2 */}
            {step === 2 && downloadUrl && (
                <div className="flex flex-col h-[80vh]"> {/* ocupa el 80% de la altura de la ventana */}
                    <h2 className="text-xl font-semibold mb-4 text-gray-700">
                        Paso 2: Vista previa
                    </h2>

                    {/* Contenedor del Swagger con scroll */}
                    <div className="flex-1 border border-gray-300 rounded-lg bg-gray-50 overflow-y-auto">
                        <div className="h-full">
                            <SwaggerUI url={downloadUrl} />
                        </div>
                    </div>

                    <div className="mt-6 flex justify-end">
                        <button
                            onClick={() => setStep(3)}
                            className="bg-[#929292] px-4 py-2 rounded text-white"
                        >
                            Continuar
                        </button>
                    </div>
                </div>
            )}

            {/* Paso 3 */}
            {step === 3 && (
                <div className="space-y-4">
                    <h2 className="text-xl font-semibold text-gray-700">
                        Paso 3: Descargar archivo
                    </h2>
                    <button
                        className="bg-[#929292] px-4 py-2 rounded text-white"
                        onClick={handleDownload}
                    >
                        Descargar archivo
                    </button>
                </div>
            )}
        </div>
    );

}

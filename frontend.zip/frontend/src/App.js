import React from "react";
import OpenApiWizard from "./components/OpenApiWizard";

function App() {
  return (
    <div className="bg-white min-h-screen">
      {/* 🏷️ Banner principal */}
      <header className="bg-[#d41775] text-white px-8 py-4 flex items-center justify-between shadow-md">
        <div className="flex items-center space-x-4">
          <img src="/logo_compartamos.png" alt="Logo de la empresa" className="h-20 w-auto" />
          <h1 className="text-2xl font-semibold">Portal Automatizador de OpenAPI</h1>
        </div>
      </header>
      {/* 🧭 Contenedor principal */}
      <main className="p-8">
        <OpenApiWizard />
      </main>

    </div>
  );
}

export default App;
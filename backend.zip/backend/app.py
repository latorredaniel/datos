from fastapi import FastAPI, UploadFile, File, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import os
import subprocess
import uuid
import shutil
from datetime import datetime
import sys

app = FastAPI(title=" Automatizador de OpenAPI", version="1.0")

# --- Configuración ---
BASE_DIR = os.getenv("BASE_DIR", os.path.dirname(os.path.abspath(__file__)))
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
SCRIPT_PATH = os.path.join(BASE_DIR, "script.py")

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- Habilitar CORS (para el futuro frontend) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/generate")
async def generate_openapi(request: Request, file: UploadFile = File(...)):
    """Sube el Excel, ejecuta el script y devuelve URL de descarga"""
    try:
        # 1️⃣ Guardar archivo temporal
        upload_filename = f"{uuid.uuid4()}_{file.filename}"
        upload_path = os.path.join(UPLOADS_DIR, upload_filename)

        with open(upload_path, "wb") as f:
            f.write(await file.read())

        # 2️⃣ Nombre único para el archivo generado
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"openapi_{uuid.uuid4()}_{timestamp}.yaml"
        output_path = os.path.join(OUTPUT_DIR, output_filename)

        # 3️⃣ Ejecutar script con parámetros
        # Tu script.py debe generar el YAML en output_path
        subprocess.run(
            [sys.executable, SCRIPT_PATH, upload_path, output_path],
            check=True,
            capture_output=True
        )

        # 4️⃣ Verificar que el archivo se haya generado
        if not os.path.exists(output_path):
            return JSONResponse(
                status_code=500,
                content={"error": "El script no generó el archivo YAML."}
            )

        # 5️⃣ Eliminar el Excel temporal
        os.remove(upload_path)

        # 6️⃣ Devolver URL de descarga
        base_url = str(request.base_url).rstrip("/")
        return {"download_url": f"{base_url}/download/{output_filename}"}

    except subprocess.CalledProcessError as e:
        return JSONResponse(
            status_code=500,
            content={
                "error": "Error al ejecutar el script",
                "details": e.stderr.decode(errors="ignore") if e.stderr else str(e)
            }
        )


    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.get("/download/{filename}")
def download_file(filename: str):
    """Permite descargar el YAML generado"""
    file_path = os.path.join(OUTPUT_DIR, filename)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Archivo no encontrado")

    # ✅ FileResponse no necesita call_on_close
    return FileResponse(
        path=file_path,
        media_type="application/x-yaml",
        filename=filename
    )


@app.delete("/cleanup/{filename}")
def cleanup_all(filename: str):
    """Elimina un archivo YAML específico (seguro)"""
    file_path = os.path.join(OUTPUT_DIR, filename)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Archivo no encontrado")

    os.remove(file_path)
    return {"status": f"Archivo '{filename}' eliminado correctamente"}

# --- Inicio local (opcional, no usado en Cloud Run) ---
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))  # 8080 local / dinámico en Cloud Run
    print(f"🚀 Servidor corriendo en http://localhost:{port}")
    uvicorn.run("app:app", host="0.0.0.0", port=port)

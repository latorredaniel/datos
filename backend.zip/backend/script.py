import re
import yaml
import pandas as pd
from collections import defaultdict
import sys
from pathlib import Path
from jinja2 import Environment,Template


# --- Dumper personalizado para indentar listas ---
class MyDumper(yaml.SafeDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super(MyDumper, self).increase_indent(flow, False)
    def ignore_aliases(self, data):
        # con esto evitas &id001/*id001
        return True
        
# --- Forzar estilo | en strings con saltos de línea ---
def str_presenter(dumper, data):
    if "\n" in data:  # Si la cadena tiene saltos de línea
        return dumper.represent_scalar("tag:yaml.org,2002:str", data.strip(), style="|")
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)

yaml.add_representer(str, str_presenter, Dumper=MyDumper)

def to_nice_yaml(value, indent=2):
    return yaml.dump(value, sort_keys=False, allow_unicode=True, indent=indent,default_flow_style=False, Dumper=MyDumper).lstrip()

# --- Configurar Jinja2 ---
env = Environment()
env.filters['to_nice_yaml'] = to_nice_yaml

# ------------------------
# Funciones utilitarias
# ------------------------
def normalize_example(tipo: str, valor):
    """Convierte el ejemplo del Excel al tipo correcto (string, int, float, bool)."""
    if pd.isna(valor):  # vacío
        return None

    tipo = str(tipo).strip().lower()

    if tipo == "integer":
        try:
            return int(valor)
        except:
            return None
    elif tipo == "number":
        try:
            return float(valor)
        except:
            return None
    elif tipo == "boolean":
        return str(valor).strip().lower() in ["true", "1", "si", "yes"]
    else:  # string u otro
        return str(valor).strip()
        
def parse_type_and_format(value: str):
    """
    Convierte algo como:
      - string
      - integer
      - array(string)
      - array(integer)
      - object
    en un dict con type/format/items
    """
    if pd.isna(value):
        return {"type": "string"}
    text = str(value).strip().lower()

    # Caso array(xxx)
    if text.startswith("array"):
        inner = text[text.find("(") + 1:text.find(")")] if "(" in text else "string"
        inner = inner.strip()
        if inner == "integer":
            items = {"type": "integer"}
        elif inner == "string":
            items = {"type": "string"}
        else:
            items = {"type": inner}
        return {"type": "array", "items": items}

    # Caso base con formato
    if "(" in text and ")" in text:
        base, fmt = text.split("(", 1)
        base = base.strip()
        fmt = fmt.replace(")", "").replace("$", "").strip()
        return {"type": base, "format": fmt}

    return {"type": text}
    
# --- Función para parsear nombre de campo ---
def parse_field_name(part: str):
    """
    Recibe un nombre de campo (ej: 'phones[]', 'person.address') y devuelve:
      - clean_name: sin los corchetes []
      - is_array: True si termina en []
    """
    part = str(part).strip()
    is_array = part.endswith("[]")
    clean_name = part[:-2] if is_array else part
    return clean_name, is_array
    
def parse_enum(enum_str, field_type):
    """
    Convierte los valores de 'Campos permitidos' a la lista de tipo correcto.
    """
    if not enum_str or pd.isna(enum_str):
        return None
    
    values = [v.strip() for v in str(enum_str).split(",")]

    if field_type == "integer":
        return [int(v) for v in values if v != ""]
    elif field_type == "number":
        return [float(v) for v in values if v != ""]
    else:  # string, object, etc.
        return values

openapi_template = """
openapi: 3.0.1
info:
  title: "{{api_name}}"
  description: "{{api_description}}"
  contact:
    name: "{{contact_name}}"
    email: "coordinadoresdepartamentodesarrollo@compartamos.pe"
    url: http://www.swagger.io/support
  license:
    name: Apache 2.0
    url: http://www.apache.org/licenses/LICENSE-2.0.html
  version: "{{version}}"
  x-production-date: "{{production_date}}"
  x-component: "{{component_name}}"
  
servers:
- url: "{{server}}{{url_server}}"
  description: Entorno Desarrollo
  
tags:
{% for tag in tags_list %}
  - name: {{ tag.name }}
    description: {{ tag.description }}
{% endfor %}
 
paths:
  {{ paths | to_nice_yaml(indent=2) | indent(2) }}    
  
  
components:
  schemas:
    {{ schemas | to_nice_yaml(indent=2) | indent(4) }}
    
  parameters:
    xapikey:
      in: header
      name: x-api-key
      schema:
        type: string
        example: vxUFgzej14D4TDmMvwF7doashuLWmQcMVULrjxEW80JcaONr
      required: true 
      description: Llave de la api en apigee.
    authorization:
      name: Authorization
      in: header
      description: >-
        Incluye la prueba de acceso (usando el modelo de seguridad OAuth2.0)
        para garantizar que el consumidor tiene privilegios para ingresar a la
        base de datos.
      required: true
      schema:
        type: string
        example: 2q5jkdf3-0das8-4gd3-a12d-at3h5g357r46 
    xchannelid:
      in: header
      name: X-Channel-ID
      schema:
        type: string
        example: "001"
      required: true 
      description: Identificador del canal por el cual se realiza la solicitud.
    timestamp:
      in: header
      name: TimeStamp
      schema:
        type: string
        format: date-time
        example: "2025-08-10T10:12:00"
      required: true 
      description: Fecha y hora de la petición que envía el canal consumidor.
    xtraceid:
      in: header
      name: X-Trace-ID
      schema:
        type: string
        minLength: 36
        maxLength: 36
        pattern: '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
        example: "62977d46-7a50-41c9-8d84-38272ac2a8df" 
      required: true 
      description: Identificador único de la transacción desde donde se invoca el servicio. Originado por el consumidor y viaja por todas las capas.
    xconsumerid:
      in: header
      name: X-Consumer-ID
      schema:
        type: string
        example: appid
      required: true 
      description: Indica el origen de la solicitud de acceso. Identifica la aplicación cliente que invoca al API. Proviene del Catalogo de Aplicaciones.
    xhostid:
      in: header
      name: X-Host-ID
      schema:
        type: string
        example: "191.20.12.11"
      required: true 
      description: Nombre del host al que se le envía la solicitud. IP del servidor que realizó la transacción. Importante para CORS.  
    userid:
      in: header
      name: User-ID
      schema:
        type: string
        example: CGONZALES
      required: true 
      description: Identificador del usuario que realizo la transacción. Se considera el código usuario BT.
    deviceid:
      in: header
      name: Device-ID
      schema:
        type: string
        example: device-001
      required: false 
      description: Identificador del dispositivo de donde se realizó la transacción.
  responses:
    {{ responses | to_nice_yaml(indent=2) | indent(4) }}
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
security:
  - BearerAuth: [] 
 """

if len(sys.argv) != 3:
    print("Uso: scripti.py <excel_entrada> <yaml_salida>")
    sys.exit(1)

file = sys.argv[1]
yaml_output = sys.argv[2]
 
# 1. Leer todas las hojas
sheets = pd.read_excel(file, sheet_name=None)

# --- Información general de la API ---
if "Api" not in sheets:
    raise ValueError("Debe existir una hoja llamada 'Api' con la información general.")

api_df = sheets["Api"]
if api_df.empty:
    raise ValueError("La hoja 'Api' está vacía.")
    
# convertimos a diccionario clave-valor
api_info = pd.Series(api_df["Valor"].values, index=api_df["Detalle"]).to_dict()

#trabajamos con los tags

tags_list = []

for key in ["business_domain","service_domain", "control_record"]:
    if key in api_info and api_info[key]:  # verificamos que exista y no sea vacío
        tag_name = api_info[key]
        
        # Condicional para definir el prefijo
        if key == "service_domain":
            prefix = "SD"
            desc="Service Domain BIAN " + tag_name
        elif key == "control_record":
            prefix = "CR"
            desc="Control Record BIAN " + tag_name
        elif key == "business_domain":
            prefix = "BD"
            desc="Business Domain BIAN " + tag_name
        

        # Concatenar prefijo con el tag_name
        full_tag_name = f"{prefix} - {tag_name}"
        
        # Evitar duplicados
        if full_tag_name not in [t["name"] for t in tags_list]:
            tags_list.append({
                "name": full_tag_name,
                "description": desc
            })

#validamos PCI

if api_info["PCI"].lower()=="si":
    tag_pci="PCI"
    if tag_pci not in [t["name"] for t in tags_list]:
            tags_list.append({
                "name": tag_pci,
                "description": "Normativa de seguridad y protección de información referente a tarjetas de crédito y débito."
            })
            
headers_response={
    "X-Trace-ID": {
        "description": "Identificador de trazabilidad",
        "schema": {
            "type": "string",
            "format": "uuid",
            "minLength": 36,
            "maxLength": 36,
            "pattern": "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
            "example": "62977d46-7a50-41c9-8d84-38272ac2a8df"
        }
    }
}

if api_info["api_type"].lower()=="experience":
    # Definimos los schemas estáticos para api de experiencia
    static_schemas = {
        "ErrorStandarResponse": {
            "allOf": [
                {"$ref": "#/components/schemas/ErrorDataDetail"},
                {
                    "type": "object",
                    "properties": {
                        "result": {"$ref": "#/components/schemas/ErrorDetail"}
                    }
                }
            ],
            "required": ["result"]
        },
        "ErrorDataDetail": {
            "type": "object",
            "properties": {
                "data": {
                    "description": "Data que contiene error",
                    "example": "Data incorrecta.",
                    "anyOf": [
                        {"type": "object", "nullable": True},
                        {
                            "type": "array",
                            "nullable": True,
                            "items": {"type": "object"}
                        }
                    ]
                }
            }
        },
        "ErrorDetail": {
            "type": "object",
            "properties": {
                "http_code": {
                    "type": "integer",
                    "description": "Código de estatus http",
                    "example": 400
                },
                "info": {
                    "type": "string",
                    "description": "Descripción del error.",
                    "example": "Bad Request."
                },
                "errors": {
                    "type": "array",
                    "items": {
                        "$ref": "#/components/schemas/ErrorGeneric"
                    }
                }
            }
        },
        "ErrorGeneric": {
            "type": "object",
            "required": ["statusCode", "userMessage", "errors"],
            "properties": {
                "statusCode": {
                    "type": "integer",
                    "description": "Código de estatus http",
                    "example": 400
                },
                "timestamp": {
                    "type": "string",
                    "format": "date-time",
                    "description": "Fecha y hora del error.",
                    "example": "2025-09-11T22:12:12"
                },
                "userMessage": {
                    "type": "string",
                    "description": "Detalle del error que se mostrará al usuario.",
                    "example": "La solicitud posee una sintaxis incorrecta o falta parametro(s) requerido(s)"
                },
                "errors": {
                    "type": "array",
                    "items": {
                        "$ref": "#/components/schemas/ErrorParams"
                    }
                }
            }
        },
        "ErrorParams": {
            "type": "object",
            "required": ["message"],
            "properties": {
                "errorCode": {
                    "type": "string",
                    "description": "Código de error.",
                    "example": "E301"
                },
                "message": {
                    "type": "string",
                    "description": "Razón del error.",
                    "example": "Invalid request parameters."
                },
                "url": {
                    "type": "string",
                    "description": "Url donde se mapea el error.",
                    "example": "/api/v1/orders"
                }
            }
        }
    }
    
    # Definimos los responses estáticos para api de experiencia
    static_responses = {
        "Err400_BadRequest": {
            "description": "BadRequest",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 400,
                            "info": "Bad Request.",
                            "errors": [
                                {
                                    "statusCode": 400,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "La solicitud posee una sintaxis incorrecta o falta parametro(s) requerido(s).",
                                    "errors": [
                                        {
                                            "errorCode": "E301",
                                            "message": "Invalid request parameters.",
                                            "url": "/api/v1/orders"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        },
        "Err401_Unauthorized": {
            "description": "Unauthorized",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 401,
                            "info": "Unauthorized.",
                            "errors": [
                                {
                                    "statusCode": 401,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "Se requiere autenticación para acceder a este recurso. Proporcione un token de acceso válido.",
                                    "errors": [
                                        {
                                            "errorCode": "E302",
                                            "message": "Auth Token not found or not authorized.",
                                            "url": "/api/v1/auth"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        },
        "Err403_Forbidden": {
            "description": "Forbidden",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 403,
                            "info": "Forbidden.",
                            "errors": [
                                {
                                    "statusCode": 403,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "El cliente no tiene permisos suficientes para acceder a este recurso.",
                                    "errors": [
                                        {
                                            "errorCode": "E303",
                                            "message": "The client does not have sufficient permissions to access this resource.",
                                            "url": "/api/v1/orders"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        },
        "Err404_NotFound": {
            "description": "NotFound",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 404,
                            "info": "Not found.",
                            "errors": [
                                {
                                    "statusCode": 404,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "El recurso solicitado no se encontró en este servidor.",
                                    "errors": [
                                        {
                                            "errorCode": "E304",
                                            "message": "Resource not found.",
                                            "url": "/api/v1/customers/98765"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        },
        "Err415_UnsupportedMediaType": {
            "description": "UnsupportedMediaType",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 415,
                            "info": "Unsupported Media Type.",
                            "errors": [
                                {
                                    "statusCode": 415,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "La entidad de solicitud tiene un tipo de medio que el servidor o el recurso no admite. Los tipos de medio admitidos son: application/json, application/xml",
                                    "errors": [
                                        {
                                            "errorCode": "E305",
                                            "message": "Unsupported Media Type.",
                                            "url": "/api/v1/customers/upload"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        },
        "Err429_TooManyRequests": {
            "description": "TooManyRequests",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 429,
                            "info": "Too many requests.",
                            "errors": [
                                {
                                    "statusCode": 429,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "Ha enviado demasiadas solicitudes en un tiempo determinado. Reduzca su frecuencia de solicitudes.",
                                    "errors": [
                                        {
                                            "errorCode": "E306",
                                            "message": "Too many requests.",
                                            "url": "/api/v1/payments/transfer"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        },
        "Err500_InternalServerError": {
            "description": "InternalServerError",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 500,
                            "info": "Internal server error.",
                            "errors": [
                                {
                                    "statusCode": 500,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "El servidor encontró una condición inesperada que le impidió cumplir con la solicitud",
                                    "errors": [
                                        {
                                            "errorCode": "E307",
                                            "message": "An unexpected error occurred on the server.",
                                            "url": "/orders/checkout/abc123"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        },
        "Err503_ServiceUnavailable": {
            "description": "ServiceUnavailable",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorStandarResponse"},
                    "example": {
                        "data": None,
                        "result": {
                            "http_code": 503,
                            "info": "Service unavailable.",
                            "errors": [
                                {
                                    "statusCode": 503,
                                    "timestamp": "2025-09-11T22:12:12",
                                    "userMessage": "El servicio de dependencia ascendente no responde. Inténtelo de nuevo más tarde.",
                                    "errors": [
                                        {
                                            "errorCode": "E308",
                                            "message": "The service is temporarily unavailable.",
                                            "url": "/payments/transfer/67890"
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                }
            },
            "headers": headers_response
        }
        
    }
    
else:
    # Definimos los schemas estáticos para api de sistemas,negocio
    static_schemas = {
        "ErrorGeneric": {
            "type": "object",
            "required": ["statusCode", "userMessage", "errors"],
            "properties": {
                "statusCode": {
                    "type": "integer",
                    "description": "Código de estatus http",
                    "example": 400
                },
                "timestamp": {
                    "type": "string",
                    "format": "date-time",
                    "description": "Fecha y hora del error.",
                    "example": "2025-09-11T22:12:12"
                },
                "userMessage": {
                    "type": "string",
                    "description": "Detalle del error que se mostrará al usuario.",
                    "example": "La solicitud posee una sintaxis incorrecta o falta parametro(s) requerido(s)"
                },
                "errors": {
                    "type": "array",
                    "items": {
                        "$ref": "#/components/schemas/ErrorParams"
                    }
                }
            }
        },
        "ErrorParams": {
            "type": "object",
            "required": ["message"],
            "properties": {
                "errorCode": {
                    "type": "string",
                    "description": "Código de error.",
                    "example": "E301"
                },
                "message": {
                    "type": "string",
                    "description": "Razón del error.",
                    "example": "Invalid request parameters."
                },
                "url": {
                    "type": "string",
                    "description": "Url donde se mapea el error.",
                    "example": "/api/v1/orders"
                }
            }
        }
    }
    
    # Definimos los responses estáticos para api de sistemas,negocio
    static_responses = {
        "Err400_BadRequest": {
            "description": "BadRequest",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 400,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "La solicitud posee una sintaxis incorrecta o falta parametro(s) requerido(s).",
                        "errors": [
                            {
                                "errorCode": "E301",
                                "message": "Invalid request parameters.",
                                "url": "/api/v1/orders"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        },
        "Err401_Unauthorized": {
            "description": "Unauthorized",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 401,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "Se requiere autenticación para acceder a este recurso. Proporcione un token de acceso válido.",
                        "errors": [
                            {
                                "errorCode": "E302",
                                "message": "Auth Token not found or not authorized.",
                                "url": "/api/v1/auth"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        },
        "Err403_Forbidden": {
            "description": "Forbidden",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 403,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "El cliente no tiene permisos suficientes para acceder a este recurso.",
                        "errors": [
                            {
                                "errorCode": "E303",
                                "message": "The client does not have sufficient permissions to access this resource.",
                                "url": "/api/v1/orders"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        },
        "Err404_NotFound": {
            "description": "NotFound",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 404,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "El recurso solicitado no se encontró en este servidor.",
                        "errors": [
                            {
                                "errorCode": "E304",
                                "message": "Resource not found.",
                                "url": "/api/v1/customers/98765"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        },
        "Err415_UnsupportedMediaType": {
            "description": "UnsupportedMediaType",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 415,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "La entidad de solicitud tiene un tipo de medio que el servidor o el recurso no admite. Los tipos de medio admitidos son: application/json, application/xml",
                        "errors": [
                            {
                                "errorCode": "E305",
                                "message": "Unsupported Media Type.",
                                "url": "/api/v1/customers/upload"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        },
        "Err429_TooManyRequests": {
            "description": "TooManyRequests",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 429,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "Ha enviado demasiadas solicitudes en un tiempo determinado. Reduzca su frecuencia de solicitudes.",
                        "errors": [
                            {
                                "errorCode": "E306",
                                "message": "Too many requests.",
                                "url": "/api/v1/payments/transfer"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        },
        "Err500_InternalServerError": {
            "description": "InternalServerError",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 500,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "El servidor encontró una condición inesperada que le impidió cumplir con la solicitud",
                        "errors": [
                            {
                                "errorCode": "E307",
                                "message": "An unexpected error occurred on the server.",
                                "url": "/orders/checkout/abc123"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        },
        "Err503_ServiceUnavailable": {
            "description": "ServiceUnavailable",
            "content": {
                "application/json": {
                    "schema": {"$ref": "#/components/schemas/ErrorGeneric"},
                    "example": {
                        "statusCode": 503,
                        "timestamp": "2025-09-11T22:12:12",
                        "userMessage": "El servicio de dependencia ascendente no responde. Inténtelo de nuevo más tarde.",
                        "errors": [
                            {
                                "errorCode": "E308",
                                "message": "The service is temporarily unavailable.",
                                "url": "/payments/transfer/67890"
                            }
                        ]
                    }
                }
            },
            "headers": headers_response
        }
        
    }
    

                    
#trabajamos con las operaciones

paths = {}
parameters = []
schemas={**static_schemas}
for sheet_name, df in sheets.items():
    # Ignorar las hojas Presentacion y API
    if sheet_name.lower() in ["presentacion", "api","arquitectura","data"]:
        continue
    
    # Verificar que la hoja tenga datos
    if df.empty:
        continue
    
     # Normalizar los nombres de columnas (eliminar espacios, pasar a minúsculas)
    columnas = [str(col).strip().lower() for col in df.columns if pd.notna(col)]

    # Solo procesar si existe la columna "definición api rest"
    if "definición api rest" not in columnas:
        print(f"Se omite la hoja '{sheet_name}' (no tiene columna 'Definición API REST').")
        continue
        
    df_dict = pd.Series(df.iloc[:, 1].values, index=df.iloc[:, 0]).to_dict()

    # Buscar columna "Behavior Qualifier"
    if "Behavior_Qualifier" in df_dict:
        # Tomar todos los valores únicos no nulos y limpiarlos
        behavior = str(df_dict["Behavior_Qualifier"]).strip()
        tag_name = "BQ - " + behavior
        if tag_name not in [t["name"] for t in tags_list]:
            tags_list.append({
                "name": tag_name,
                "description": f"Behavior Qualifier BIAN {behavior}"
            })
            
    # Recuperar campos principales
    valid_methods = ["get", "post", "put", "delete", "patch"]
    method = str(df_dict.get("Method", "")).lower()
    if method not in valid_methods:
        raise ValueError(f"Método HTTP inválido o faltante en la hoja {sheet_name}: {method}")
    path = str(df_dict.get("Path", "")).strip().strip('"')
    behavior = str(df_dict.get("Behavior_Qualifier", "")).strip()
    sub_qualifier = str(df_dict.get("Sub_Qualifier", "")).strip()
    action_term = str(df_dict.get("Action_Term", "")).strip()
    req_obj = df_dict.get("Object_Request")
    res_obj = df_dict.get("Object_Response")
    req_obj_type= df_dict.get("Object_Request_type")
    res_obj_type= df_dict.get("Object_Response_type")
    funcionalidad = str(df_dict.get("Funcionalidad", "")).strip()
    # Normalizar valores: si es NaN o vacío -> None
    req_obj = None if pd.isna(req_obj) or str(req_obj).strip() == "" else str(req_obj).strip()
    res_obj = None if pd.isna(res_obj) or str(res_obj).strip() == "" else str(res_obj).strip()
    # Si existe un behavior, concatenamos el prefijo
    
    behavior_tag = f"BQ - {behavior}" if behavior else None
    
    # Construir operationId (ejemplo con Action_Term + Sub_Qualifier)
    operation_id = ""
    if df_dict.get("Sub_Qualifier"):
        operation_id = f"{action_term.lower()}{behavior}{sub_qualifier}"
    else:
        operation_id = f"{action_term.lower()}{behavior}"
    
    

    if not path or not method:
        continue  # ignorar si faltan datos críticos

    # Inicializar estructura si no existe
    if path not in paths:
        paths[path] = {}
        
    #agregar descripción
    desc_path= f"""
### Propósito
- {funcionalidad.strip()}"""
        
    #agregar parametros por defecto
    default_parameters = [
    {"$ref": "#/components/parameters/xchannelid"},
    {"$ref": "#/components/parameters/authorization"},
    {"$ref": "#/components/parameters/timestamp"},
    {"$ref": "#/components/parameters/xtraceid"},
    {"$ref": "#/components/parameters/xconsumerid"},
    {"$ref": "#/components/parameters/xhostid"},
    {"$ref": "#/components/parameters/userid"},
    {"$ref": "#/components/parameters/deviceid"}
    ]
    if api_info["api_type"].lower()=="experience":
        default_parameters.append({"$ref": "#/components/parameters/xapikey"})
    
    
    #sección de body
    
    df_raw = pd.read_excel(file, sheet_name, header=None)

    # Detectar fila de cabecera (la que contiene "Tipo body")
    header_row_idx = df_raw.index[
        df_raw.apply(lambda r: r.astype(str).str.contains("Tipo body", case=False, na=False).any(), axis=1)
    ][0]

    # Volvemos a leer usando esa fila como header
    df1 = pd.read_excel(file, sheet_name, header=header_row_idx)
    
    #Trabajando con headers
    # Filtrar registros donde Tipo body = 'header' (ignorando mayúsculas/minúsculas)

    header_df = df1[df1["Tipo body"].str.strip().str.lower() == "header"]

    # Eliminar filas con Nombre del campo vacío (NaN)
    header_df = header_df[header_df["Nombre del campo"].notna()]

    header_parameters = []
    for _, row in header_df.iterrows():
        typeField= row["Tipo de dato"]
        exampleValue= row["Ejemplo de dato"]
        schema_type = parse_type_and_format(typeField)
        param = {
            "name": row["Nombre del campo"].strip(),
            "in": "header",
            "required": str(row["Obligatorio"]).strip().upper() == "SI",
            "schema": schema_type
        }
        example= normalize_example(schema_type.get("type"), exampleValue)
        if example is not None:  # solo si hay valor
            param["schema"]["example"] = example
        header_parameters.append(param)
        
        descripcion = row.get("Descripción del campo", None)
        if pd.notna(descripcion):  # solo agregar si no es NaN
            param["description"] = str(descripcion).strip()
            
        if not pd.isna(row.get("Campos permitidos")):
            enum_vals = parse_enum(row["Campos permitidos"], schema_type.get("type"))
            if enum_vals:
                param["schema"]["enum"] = enum_vals
        query_parameters.append(param)
     
    #Trabajando con query parameters
    # Filtrar registros donde Tipo body = 'query' (ignorando mayúsculas/minúsculas)

    query_df = df1[df1["Tipo body"].str.strip().str.lower() == "query"]

    # Eliminar filas con Nombre del campo vacío (NaN)
    query_df = query_df[query_df["Nombre del campo"].notna()]

    query_parameters = []
    for _, row in query_df.iterrows():
        typeField= row["Tipo de dato"]
        exampleValue= row["Ejemplo de dato"]
        schema_type = parse_type_and_format(typeField)
        param = {
            "name": row["Nombre del campo"].strip(),
            "in": "query",
            "required": str(row["Obligatorio"]).strip().upper() == "SI",
            "schema": schema_type
        }
        example= normalize_example(schema_type.get("type"), exampleValue)
        if example is not None:  # solo si hay valor
            param["schema"]["example"] = example
            
        descripcion = row.get("Descripción del campo", None)
        if pd.notna(descripcion):  # solo agregar si no es NaN
            param["description"] = str(descripcion).strip()
            
        if not pd.isna(row.get("Campos permitidos")):
            enum_vals = parse_enum(row["Campos permitidos"], schema_type.get("type"))
            if enum_vals:
                param["schema"]["enum"] = enum_vals
        query_parameters.append(param)
        
    #Trabajando con path parameters
    # Filtrar registros donde Tipo body = 'path' (ignorando mayúsculas/minúsculas)

    path_df = df1[df1["Tipo body"].str.strip().str.lower() == "path"]

    # Eliminar filas con Nombre del campo vacío (NaN)
    path_df = path_df[path_df["Nombre del campo"].notna()]

    path_parameters = []
    for _, row in path_df.iterrows():
        typeField= row["Tipo de dato"]
        exampleValue= row["Ejemplo de dato"]
        schema_type = parse_type_and_format(typeField)
        param = {
            "name": row["Nombre del campo"].strip(),
            "in": "path",
            "required": str(row["Obligatorio"]).strip().upper() == "SI",
            "schema": schema_type
        }
        example= normalize_example(schema_type.get("type"), exampleValue)
        if example is not None:  # solo si hay valor
            param["schema"]["example"] = example
        path_parameters.append(param)
        
        descripcion = row.get("Descripción del campo", None)
        if pd.notna(descripcion):  # solo agregar si no es NaN
            param["description"] = str(descripcion).strip()
            
        if not pd.isna(row.get("Campos permitidos")):
            enum_vals = parse_enum(row["Campos permitidos"], schema_type.get("type"))
            if enum_vals:
                param["schema"]["enum"] = enum_vals
        query_parameters.append(param)
        
    #Trabajando con Objeto request         
    if req_obj:
        
        request_df = df1[df1["Tipo body"].str.strip().str.lower() == "request"]
        # Eliminar filas con Nombre del campo vacío (NaN)
        request_df = request_df[request_df["Nombre del campo"].notna()]
        
        if req_obj not in schemas:
            schemas[req_obj] = {"type": "object", "properties": {}}
        
        for _, row in request_df.iterrows():
            field_path = str(row["Nombre del campo"]).strip().split(".")
            schema_info = parse_type_and_format(row["Tipo de dato"])
            obligatorio = str(row["Obligatorio"]).strip().upper() == "SI"

            current_schema = schemas[req_obj]

            for i, part in enumerate(field_path):
                clean_part, is_array = parse_field_name(part)
                is_last = i == len(field_path) - 1
                # --- Ajuste aquí: solo primera letra en mayúscula ---
                ref_name = clean_part[0].upper() + clean_part[1:] if clean_part else clean_part 
                if is_last:
                    # Campo final
                    if schema_info["type"] == "object":
                   
                        #ref_name = part.capitalize()
                        prop_def = {"$ref": f"#/components/schemas/{ref_name}"}
                        if is_array:
                            prop_def = {"type": "array", "items": prop_def}
                        current_schema["properties"][clean_part] = prop_def
                        
                        if ref_name not in schemas:
                            schemas[ref_name] = {"type": "object", "properties": {}}
                            
                    elif schema_info["type"] == "array":
                        
                        prop_def = dict(schema_info)
                        if not pd.isna(row.get("Descripción del campo")):
                            prop_def["description"] = str(row["Descripción del campo"]).strip()
                        if not pd.isna(row.get("Ejemplo de dato")):
                            prop_def["example"] = normalize_example(schema_info.get("type"),row["Ejemplo de dato"])
                        # --- ENUM para arrays de primitivos (opcional) ---
                        if not pd.isna(row.get("Campos permitidos")):
                            enum_vals = parse_enum(row["Campos permitidos"], schema_info.get("type"))
                            if enum_vals:
                                prop_def["items"]["enum"] = enum_vals
                            #enum_vals = [v.strip() for v in str(row["Campos permitidos"]).split(",")]
                            #prop_def["items"]["enum"] = enum_vals
                        current_schema["properties"][clean_part] = prop_def

                    else:
                        
                        prop_def = dict(schema_info)
                        if not pd.isna(row.get("Descripción del campo")):
                            prop_def["description"] = str(row["Descripción del campo"]).strip()
                        if not pd.isna(row.get("Ejemplo de dato")):
                            prop_def["example"] = normalize_example(schema_info.get("type"),row["Ejemplo de dato"])
                        # --- ENUM para primitivos ---
                        if not pd.isna(row.get("Campos permitidos")):
                            enum_vals = parse_enum(row["Campos permitidos"], schema_info.get("type"))
                            if enum_vals:
                                prop_def["enum"] = enum_vals
                            #enum_vals = [v.strip() for v in str(row["Campos permitidos"]).split(",")]
                            #prop_def["enum"] = enum_vals
                        if is_array:
                            prop_def = {"type": "array", "items": prop_def}
                        current_schema["properties"][clean_part] = prop_def

                    # Si es obligatorio
                    if obligatorio:
                        current_schema.setdefault("required", [])
                        if clean_part not in current_schema["required"]:
                            current_schema["required"].append(clean_part)
                else:
                    # Nivel intermedio
                    
                    #ref_name = clean_part.capitalize()
                    if clean_part not in current_schema["properties"]:
                        ref_def = {"$ref": f"#/components/schemas/{ref_name}"}
                        if is_array:
                            ref_def = {"type": "array", "items": ref_def}
                        current_schema["properties"][clean_part] = ref_def
                    
                    if ref_name not in schemas:
                        schemas[ref_name] = {"type": "object", "properties": {}}
                    current_schema = schemas[ref_name]
        
    #Trabajando con Objeto response         
    if res_obj:
        
        response_df = df1[df1["Tipo body"].str.strip().str.lower() == "response"]
        # Eliminar filas con Nombre del campo vacío (NaN)
        response_df = response_df[response_df["Nombre del campo"].notna()]
        
        if res_obj not in schemas:
            schemas[res_obj] = {"type": "object", "properties": {}}
        
        for _, row in response_df.iterrows():
            field_path = str(row["Nombre del campo"]).strip().split(".")
            schema_info = parse_type_and_format(row["Tipo de dato"])
            obligatorio = str(row["Obligatorio"]).strip().upper() == "SI"

            current_schema = schemas[res_obj]

            for i, part in enumerate(field_path):
                clean_part, is_array = parse_field_name(part)
                is_last = i == len(field_path) - 1
                # --- Ajuste aquí: solo primera letra en mayúscula ---
                ref_name = clean_part[0].upper() + clean_part[1:] if clean_part else clean_part 
                if is_last:
                    # Campo final
                    if schema_info["type"] == "object":
                   
                        #ref_name = part.capitalize()
                        prop_def = {"$ref": f"#/components/schemas/{ref_name}"}
                        if is_array:
                            prop_def = {"type": "array", "items": prop_def}
                        current_schema["properties"][clean_part] = prop_def
                        
                        if ref_name not in schemas:
                            schemas[ref_name] = {"type": "object", "properties": {}}
                            
                    elif schema_info["type"] == "array":
                        
                        prop_def = dict(schema_info)
                        if not pd.isna(row.get("Descripción del campo")):
                            prop_def["description"] = str(row["Descripción del campo"]).strip()
                        if not pd.isna(row.get("Ejemplo de dato")):
                            prop_def["example"] = normalize_example(schema_info.get("type"),row["Ejemplo de dato"])
                        # --- ENUM para arrays de primitivos (opcional) ---
                        if not pd.isna(row.get("Campos permitidos")):
                            enum_vals = parse_enum(row["Campos permitidos"], schema_info.get("type"))
                            if enum_vals:
                                prop_def["items"]["enum"] = enum_vals    
                        current_schema["properties"][clean_part] = prop_def

                    else:
                        
                        prop_def = dict(schema_info)
                        if not pd.isna(row.get("Descripción del campo")):
                            prop_def["description"] = str(row["Descripción del campo"]).strip()
                        if not pd.isna(row.get("Ejemplo de dato")):
                            prop_def["example"] = normalize_example(schema_info.get("type"),row["Ejemplo de dato"])
                        # --- ENUM para primitivos ---
                        if not pd.isna(row.get("Campos permitidos")):
                            enum_vals = parse_enum(row["Campos permitidos"], schema_info.get("type"))
                            if enum_vals:
                                prop_def["enum"] = enum_vals
                        if is_array:
                            prop_def = {"type": "array", "items": prop_def}
                        current_schema["properties"][clean_part] = prop_def

                    # Si es obligatorio
                    if obligatorio:
                        current_schema.setdefault("required", [])
                        if clean_part not in current_schema["required"]:
                            current_schema["required"].append(clean_part)
                else:
                    # Nivel intermedio
                    
                    #ref_name = clean_part.capitalize()
                    if clean_part not in current_schema["properties"]:
                        ref_def = {"$ref": f"#/components/schemas/{ref_name}"}
                        if is_array:
                            ref_def = {"type": "array", "items": ref_def}
                        current_schema["properties"][clean_part] = ref_def
                    
                    if ref_name not in schemas:
                        schemas[ref_name] = {"type": "object", "properties": {}}
                    current_schema = schemas[ref_name]
    


 
    
    #validar si la operación deb devolver codigo 204
    
    if action_term.lower()=="create":
        cod_response_succes="201"
        des_response_succes="Created"
    else:
        cod_response_succes="200"
        des_response_succes="OK"
        
    #errores por defecto
    default_error_responses = {
        "400": {"$ref": "#/components/responses/Err400_BadRequest"},
        "401": {"$ref": "#/components/responses/Err401_Unauthorized"},
        "403": {"$ref": "#/components/responses/Err403_Forbidden"},
        "404": {"$ref": "#/components/responses/Err404_NotFound"},
        "415": {"$ref": "#/components/responses/Err415_UnsupportedMediaType"},
        "429": {"$ref": "#/components/responses/Err429_TooManyRequests"},
        "500": {"$ref": "#/components/responses/Err500_InternalServerError"},
        "503": {"$ref": "#/components/responses/Err503_ServiceUnavailable"},
    }
    
    # Headers por defecto
    default_headers_response = {
        "X-Trace-ID": {
            "description": "Identificador de trazabilidad",
            "schema": {
                "type": "string",
                "format": "uuid",
                "minLength": 36,
                "maxLength": 36,
                "pattern": "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
                "example": "62977d46-7a50-41c9-8d84-38272ac2a8df",
            }
        }
    }
    # Crear operación
    paths[path][method] = {
        "tags": [behavior_tag] if behavior_tag else [],
        "description": desc_path,
        "summary": f"{funcionalidad}".strip(),
        "operationId": operation_id,
        "parameters": default_parameters + header_parameters + path_parameters + query_parameters,
        **(
            {
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": 
                                 # Si req_obj_type == "array"
                                {"type": "array", "items": {"$ref": f"#/components/schemas/{req_obj}"}}
                                if str(req_obj_type).strip().lower() == "array"
                                else
                                # Si req_obj_type == "object"
                                {"$ref": f"#/components/schemas/{req_obj}"}
                        }
                    }
                }
            } if req_obj else {}
        ),
        "responses": {
            **(
                {
                    cod_response_succes: {
                        "description": des_response_succes,
                        "content": {
                            "application/json": {
                                "schema": 
                                     # Si res_obj_type == "array"
                                    {"type": "array", "items": {"$ref": f"#/components/schemas/{res_obj}"}}
                                    if str(res_obj_type).strip().lower() == "array"
                                    else
                                    # Si res_obj_type == "object"
                                    {"$ref": f"#/components/schemas/{res_obj}"}
                            }
                        },
                        "headers": default_headers_response
                    }
                } if res_obj else {
                     "204": {
                        "description": "No Content",
                        "headers": default_headers_response
                    }
                
                }
            ),
            **default_error_responses  #aquí insertas la lista de errores
        }
    }



# 4) cargar plantilla
#template = Template(openapi_template)
template = env.from_string(openapi_template)

# --- Renderizar plantilla ---
output = template.render(
    api_name=api_info["api_name"],
    api_description=api_info["description"],
    version=api_info["version"],
    production_date=api_info["production_date"],
    contact_name=api_info["contact_name"],
    component_name=api_info["component"],
    server=api_info["server"],
    url_server=api_info["base_path"],
    tags_list=tags_list,  # pasamos la lista directamente, sin usar yaml.dump
    #paths=yaml.dump(paths, sort_keys=False, allow_unicode=True, indent=2)
    paths=paths,
    schemas=schemas,
    responses=static_responses
    
)



# --- Guardar archivo ---
with open(yaml_output, "w", encoding="utf-8") as f:
   f.write(output.lstrip())
   

print(f"Archivo  generado con éxito")

    
    
 